#include "Log.hpp"
#include "Log_collector.hpp"
#include <iostream>

int main() {
    // 1. Créer une instance de Log_collector avec le chemin "test.xml"
    Log_collector collector("Log_test/test.xml");

    // 2. Utiliser la méthode importer() pour obtenir un objet Log
    Log log = collector.importer();

    // 3. Afficher les informations du Log avec la méthode afficher()
    log.afficher();



    return 0;
}