#ifndef LOG_COLLECTOR_HPP
#define LOG_COLLECTOR_HPP
#include <iostream>
#include <vector>
#include "Log.hpp"

class Log_collector {

    private:

        int ID_Log;
        std::string chemin;

    public:

        Log_collector(const std::string& path);

        ~Log_collector();

        Log importer(); // prend une instance de Log_collector et le transforme en une instance de Log

        std::vector<Windows_Security_Log> importer_liste_Windows_Security_Log();

        std::vector<Windows_System_Log> importer_liste_Windows_System_Log();
};

#endif