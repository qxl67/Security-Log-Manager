#ifndef LOG_HPP
#define LOG_HPP
#include <iostream>


class Log {
    protected:

        int ID_Log = -1; //attributs et fonctions que les classes héritées auront

    private:

        std::string synthesis_message = "";
        std::string host = "";
        std::string event_type = "";
        std::string PID = "";
        std::string time_stamp = "";
        std::string user = "";

    public:

        Log(int id, const std::string& message, const std::string& h, const std::string& type, const std::string& pid, const std::string& timestamp, const std::string& u);
        
        Log() = default; // Default constructor

        virtual ~Log();

        virtual void afficher();
};

class Windows_System_Log : public Log{
    private:

        std::string name = "";
        std::string guid = "";
        std::string event_ID = "";
        std::string version = "";
        std::string level = "";
        std::string task = "";
        std::string opcode = "";
        std::string keywords = "";
        std::string eventRecordID = "";
        std::string activityID = "";
        std::string threadID = "";
        std::string channel = "";
        std::string computer = "";
        std::string userID = "";

    public:

        Windows_System_Log(int id,
            const std::string& message,
            const std::string& host,
            const std::string& type,
            const std::string& pid,
            const std::string& timestamp,
            const std::string& user,
            //Au dessus attributs de Log, en dessous attributs de la classe héritière
            const std::string& name,
            const std::string& guid,
            const std::string& event_ID,
            const std::string& version,
            const std::string& level,
            const std::string& task,
            const std::string& opcode,
            const std::string& keywords,
            const std::string& eventRecordID,
            const std::string& activityID,
            const std::string& threadID,
            const std::string& channel,
            const std::string& computer,
            const std::string& userID);
        
        ~Windows_System_Log() override;

        void afficher() override;
};


class Windows_Security_Log : public Log{
    private:

        std::string name = "";
        std::string guid = "";
        std::string event_ID = "";
        std::string version = "";
        std::string level = "";
        std::string task = "";
        std::string opcode = "";
        std::string keywords = "";
        std::string eventRecordID = "";
        std::string activityID = "";
        std::string threadID = "";
        std::string channel = "";
        std::string computer = "";

    public:

        Windows_Security_Log(int id,
            const std::string& message,
            const std::string& host,
            const std::string& type,
            const std::string& pid,
            const std::string& timestamp,
            const std::string& user,
            //Au dessus attributs de Log, en dessous attributs de la classe héritière
            const std::string& name,
            const std::string& guid,
            const std::string& event_ID,
            const std::string& version,
            const std::string& level,
            const std::string& task,
            const std::string& opcode,
            const std::string& keywords,
            const std::string& eventRecordID,
            const std::string& activityID,
            const std::string& threadID,
            const std::string& channel,
            const std::string& computer);
        
        ~Windows_Security_Log() override;

        void afficher() override;
};



class Linux_System_Log : public Log{
    private:

        std::string host_name = "";
        std::string process = "";
        std::string sevenity = "";

    public:

        Linux_System_Log(int id,
            const std::string& message,
            const std::string& host,
            const std::string& type,
            const std::string& pid,
            const std::string& timestamp,
            const std::string& user,
            //Au dessus attributs de Log, en dessous attributs de la classe héritière
            const std::string& host_name,
            const std::string& process,
            const std::string& sevenity);
        
        ~Linux_System_Log() override;

        void afficher() override;
};



class Linux_Security_Log : public Log{
    private:

        std::string host_name = "";
        std::string process = "";
        std::string sevenity = "";
        std::string action = "";
        std::string source_ip = "";

    public:

        Linux_Security_Log(int id,
            const std::string& message,
            const std::string& host,
            const std::string& type,
            const std::string& pid,
            const std::string& timestamp,
            const std::string& user,
            //Au dessus attributs de Log, en dessous attributs de la classe héritière
            const std::string& host_name,
            const std::string& process,
            const std::string& sevenity,
            const std::string& action,
            const std::string& source_ip);
        
        ~Linux_Security_Log() override;

        void afficher() override;
};

#endif