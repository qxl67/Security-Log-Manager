#include "Log.hpp"
#include <iostream>



Log::Log(int id,
    const std::string& message,
    const std::string& h,
    const std::string& type,
    const std::string& pid,
    const std::string& timestamp,
    const std::string& u)
    : ID_Log(id),
    synthesis_message(message),
    host(h),
    event_type(type),
    PID(pid),
    time_stamp(timestamp),
    user(u) {
        // vérifications
    }

Log::~Log() {
    // ressources à libérer
}

void Log::afficher() {
    std::cout << "ID_Log: " << ID_Log << std::endl;
    std::cout << "Synthesis Message: " << synthesis_message << std::endl;
    std::cout << "Host: " << host << std::endl;
    std::cout << "Event Type: " << event_type << std::endl;
    std::cout << "PID: " << PID << std::endl;
    std::cout << "Time Stamp: " << time_stamp << std::endl;
    std::cout << "User: " << user << std::endl;
}

// Windows_System_Log/////////////////////////////////////////////////////////////////////////

Windows_System_Log::Windows_System_Log(
    int id,
    const std::string& message,
    const std::string& host,
    const std::string& type,
    const std::string& pid,
    const std::string& timestamp,
    const std::string& user,


    const std::string& name,
    const std::string& guid,
    const std::string& event_ID,
    const std::string& version,
    const std::string& level,
    const std::string& task,
    const std::string& opcode,
    const std::string& keywords,
    const std::string& eventRecordID,
    const std::string& activityID,
    const std::string& threadID,
    const std::string& channel,
    const std::string& computer,
    const std::string& userID)
    : Log(id, message, host, type, pid, timestamp, user),
    name(name),
    guid(guid),
    event_ID(event_ID),
    version(version),
    level(level),
    task(task),
    opcode(opcode),
    keywords(keywords),
    eventRecordID(eventRecordID),
    activityID(activityID),
    threadID(threadID),
    channel(channel),
    computer(computer),
    userID(userID)    {
        // vérifications
    }

Windows_System_Log::~Windows_System_Log() {
    // ressources à libérer
}

void Windows_System_Log::afficher() {
    // Appel de l'affichage de la classe mère
    Log::afficher();

    // Affichage spécifique Windows Security
    std::cout << "Name: " << name << std::endl;
    std::cout << "GUID: " << guid << std::endl;
    std::cout << "Event ID: " << event_ID << std::endl;
    std::cout << "Version: " << version << std::endl;
    std::cout << "Level: " << level << std::endl;
    std::cout << "Task: " << task << std::endl;
    std::cout << "Opcode: " << opcode << std::endl;
    std::cout << "Keywords: " << keywords << std::endl;
    std::cout << "EventRecordID: " << eventRecordID << std::endl;
    std::cout << "ActivityID: " << activityID << std::endl;
    std::cout << "ThreadID: " << threadID << std::endl;
    std::cout << "Channel: " << channel << std::endl;
    std::cout << "Computer: " << computer << std::endl;
    std::cout << "UserID: " << userID << std::endl;
}

// Windows_Security_Log/////////////////////////////////////////////////////////////////////////

Windows_Security_Log::Windows_Security_Log(
    int id,
    const std::string& message,
    const std::string& host,
    const std::string& type,
    const std::string& pid,
    const std::string& timestamp,
    const std::string& user,


    const std::string& name,
    const std::string& guid,
    const std::string& event_ID,
    const std::string& version,
    const std::string& level,
    const std::string& task,
    const std::string& opcode,
    const std::string& keywords,
    const std::string& eventRecordID,
    const std::string& activityID,
    const std::string& threadID,
    const std::string& channel,
    const std::string& computer)
    : Log(id, message, host, type, pid, timestamp, user),
    name(name),
    guid(guid),
    event_ID(event_ID),
    version(version),
    level(level),
    task(task),
    opcode(opcode),
    keywords(keywords),
    eventRecordID(eventRecordID),
    activityID(activityID),
    threadID(threadID),
    channel(channel),
    computer(computer)    {
        // vérifications
    }

Windows_Security_Log::~Windows_Security_Log() {
    // ressources à libérer
}

void Windows_Security_Log::afficher() {
    // Appel de l'affichage de la classe mère
    Log::afficher();

    // Affichage spécifique Windows Security
    std::cout << "Name: " << name << std::endl;
    std::cout << "GUID: " << guid << std::endl;
    std::cout << "Event ID: " << event_ID << std::endl;
    std::cout << "Version: " << version << std::endl;
    std::cout << "Level: " << level << std::endl;
    std::cout << "Task: " << task << std::endl;
    std::cout << "Opcode: " << opcode << std::endl;
    std::cout << "Keywords: " << keywords << std::endl;
    std::cout << "EventRecordID: " << eventRecordID << std::endl;
    std::cout << "ActivityID: " << activityID << std::endl;
    std::cout << "ThreadID: " << threadID << std::endl;
    std::cout << "Channel: " << channel << std::endl;
    std::cout << "Computer: " << computer << std::endl;
}

// Linux_System_Log/////////////////////////////////////////////////////////////////////////

Linux_System_Log::Linux_System_Log(
    int id,
    const std::string& message,
    const std::string& host,
    const std::string& type,
    const std::string& pid,
    const std::string& timestamp,
    const std::string& user,


    const std::string& host_name,
    const std::string& process,
    const std::string& sevenity)
    : Log(id, message, host, type, pid, timestamp, user),
    host_name(host_name),
    process(process),
    sevenity(sevenity)    {
        // vérifications
    }

Linux_System_Log::~Linux_System_Log() {
    // ressources à libérer
}

void Linux_System_Log::afficher() {
    // Appel de l'affichage de la classe mère
    Log::afficher();

    // Affichage spécifique Windows Security
    std::cout << "Host Name: " << host_name << std::endl;
    std::cout << "Process: " << process << std::endl;
    std::cout << "Sevenity: " << sevenity << std::endl;
}

// Linux_Security_Log/////////////////////////////////////////////////////////////////////////

Linux_Security_Log::Linux_Security_Log(
    int id,
    const std::string& message,
    const std::string& host,
    const std::string& type,
    const std::string& pid,
    const std::string& timestamp,
    const std::string& user,


    const std::string& host_name,
    const std::string& process,
    const std::string& sevenity,
    const std::string& action,
    const std::string& source_ip)
    : Log(id, message, host, type, pid, timestamp, user),
    host_name(host_name),
    process(process),
    sevenity(sevenity),
    action(action),
    source_ip(source_ip)    {
        // vérifications
    }

Linux_Security_Log::~Linux_Security_Log() {
    // ressources à libérer
}

void Linux_Security_Log::afficher() {
    // Appel de l'affichage de la classe mère
    Log::afficher();

    // Affichage spécifique Windows Security
    std::cout << "Host Name: " << host_name << std::endl;
    std::cout << "Process: " << process << std::endl;
    std::cout << "Sevenity: " << sevenity << std::endl;
    std::cout << "Action: " << action << std::endl;
    std::cout << "Soucrce IP: " << source_ip << std::endl;
}