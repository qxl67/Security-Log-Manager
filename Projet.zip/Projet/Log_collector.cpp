#include "Log_collector.hpp"
#include "Log.hpp"

#include "pugixml.hpp"

#include <iostream>
#include <vector>


Log_collector::Log_collector(const std::string& path)
    : chemin(path) 
    {
    pugi::xml_document log;
    pugi::xml_parse_result parsing = log.load_file(chemin.c_str());
    ID_Log = log.child("Log").child("ID_Log").text().as_int();
    }

Log_collector::~Log_collector() {
    // ressources à libérer
}

Log Log_collector::importer()   {
    pugi::xml_document log;
    pugi::xml_parse_result parsing = log.load_file(chemin.c_str());
    // if (!parsing) {
        // std::cout << "Erreur de parsing : " << std::endl;
        // break
    // }
    return Log(ID_Log, 
    log.child("Log").child("synthesis_message").text().as_string(), 
    log.child("Log").child("host").text().as_string(), 
    log.child("Log").child("event_type").text().as_string(), 
    log.child("Log").child("PID").text().as_string(), 
    log.child("Log").child("time_stamp").text().as_string(), 
    log.child("Log").child("user").text().as_string());
}

/////////////////////////////////////////////////////////////////////////////////////////////////

std::vector<Windows_Security_Log> Log_collector::importer_liste_Windows_Security_Log() {
    std::vector<Windows_Security_Log> logs;

    pugi::xml_document doc;
    pugi::xml_parse_result result = doc.load_file(chemin.c_str());
    // if (!result) {
        // std::cerr << "Erreur parsing: " << result.description() << std::endl;
        // return logs; // retourne vecteur vide en cas d'erreur
    // }

    // itération sur tous les Event
    for (pugi::xml_node event_node : doc.children("Event")) {

        // récupération des champs System
        pugi::xml_node system = event_node.child("System");
        std::string provider_name = system.child("Provider").attribute("Name").as_string();
        std::string guid = system.child("Provider").attribute("Guid").as_string();
        std::string eventID = system.child("EventID").text().as_string();
        std::string version = system.child("Version").text().as_string();
        std::string level = system.child("Level").text().as_string();
        std::string task = system.child("Task").text().as_string();
        std::string opcode = system.child("Opcode").text().as_string();
        std::string keywords = system.child("Keywords").text().as_string();
        std::string eventRecordID = system.child("EventRecordID").text().as_string();
        std::string activityID = system.child("Correlation").attribute("ActivityID").as_string();
        std::string threadID = system.child("Execution").attribute("ThreadID").as_string();
        std::string channel = system.child("Channel").text().as_string();
        std::string computer = system.child("Computer").text().as_string();

        // créer le log
        logs.push_back(Windows_Security_Log(
            -1,
            "",
            "",
            "",
            "",
            "",
            provider_name,
            guid,
            eventID,
            version,
            level,
            task,
            opcode,
            keywords,
            eventRecordID,
            activityID,
            threadID,
            channel,
            computer));
    }
    return logs;
}

///////////////////////////////////////////////////////////////////////////////////////////////

std::vector<Windows_System_Log> Log_collector::importer_liste_Windows_System_Log() {
    std::vector<Windows_System_Log> logs;

    pugi::xml_document doc;
    pugi::xml_parse_result result = doc.load_file(chemin.c_str());
    // if (!result) {
        // std::cerr << "Erreur parsing: " << result.description() << std::endl;
        // return logs; // retourne vecteur vide en cas d'erreur
    // }

    // itération sur tous les Event
    for (pugi::xml_node event_node : doc.children("Event")) {

        // récupération des champs System
        pugi::xml_node system = event_node.child("System");
        std::string provider_name = system.child("Provider").attribute("Name").as_string();
        std::string guid = system.child("Provider").attribute("Guid").as_string();
        std::string eventID = system.child("EventID").text().as_string();
        std::string version = system.child("Version").text().as_string();
        std::string level = system.child("Level").text().as_string();
        std::string task = system.child("Task").text().as_string();
        std::string opcode = system.child("Opcode").text().as_string();
        std::string keywords = system.child("Keywords").text().as_string();
        std::string eventRecordID = system.child("EventRecordID").text().as_string();
        std::string activityID = system.child("Correlation").attribute("ActivityID").as_string();
        std::string threadID = system.child("Execution").attribute("ThreadID").as_string();
        std::string channel = system.child("Channel").text().as_string();
        std::string computer = system.child("Computer").text().as_string();
        pugi::xml_node securityNode = system.child("Security");
        std::string userID = securityNode.attribute("UserID").as_string();

        // créer le log
        logs.push_back(Windows_Security_Log(
            -1,
            "",
            "",
            "",
            "",
            "",
            provider_name,
            guid,
            eventID,
            version,
            level,
            task,
            opcode,
            keywords,
            eventRecordID,
            activityID,
            threadID,
            channel,
            computer,
            userID));
    }
    return logs;
}